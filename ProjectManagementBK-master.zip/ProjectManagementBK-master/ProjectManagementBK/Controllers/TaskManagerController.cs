﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using ProjectManagement.Entities;
using ProjectManagement.BusinessLayer;

namespace ProjectManagementBK.Controllers
{
    public class TaskManagerController : ApiController
    {
        // GET: api/TaskManager
        [HttpGet]
        public IEnumerable<Task> Get()
        {
            ProjectManagementBusinessLayer businessLayer = new ProjectManagementBusinessLayer();
            return businessLayer.GetAllTasks();
        }

        // GET: api/TaskManager/5
        [HttpGet]
        public Task Get(int id)
        {
            ProjectManagementBusinessLayer businessLayer = new ProjectManagementBusinessLayer();
            return businessLayer.GetTask(id);
        }

        // POST: api/TaskManager
        [HttpPost]
        public string AddTask(Task task)
        {
            ProjectManagementBusinessLayer businessLayer = new ProjectManagementBusinessLayer();
            return businessLayer.AddTask(task);
            
        }

        // PUT: api/TaskManager/5
        [HttpPut]
        public string EditTask(Task task)
        {
            ProjectManagementBusinessLayer businessLayer = new ProjectManagementBusinessLayer();
            return businessLayer.EditTask(task);
        }

        // DELETE: api/TaskManager/5
        [HttpDelete]
        public string DeleteTask(int id)
        {
            ProjectManagementBusinessLayer businessLayer = new ProjectManagementBusinessLayer();
            return businessLayer.DeleteTask(id);
        }
    }
}
