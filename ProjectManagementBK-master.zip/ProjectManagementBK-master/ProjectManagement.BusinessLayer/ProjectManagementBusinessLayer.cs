﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ProjectManagement.Entities;
using ProjectManagement.DataLayer;
using System.Data.Entity;
namespace ProjectManagement.BusinessLayer
{
    public class ProjectManagementBusinessLayer
    {
        public List<Task> GetAllTasks()
        {
            ProjectManagementDbContext dbContext = new ProjectManagementDbContext();            
            return dbContext.Tasks.Include(p=>p.ParentTask).ToList();
        }

        public Task GetTask(int id)
        {
            ProjectManagementDbContext dbContext = new ProjectManagementDbContext();
            return dbContext.Tasks.Include("ParentTask").Where(t => t.TaskID == id).FirstOrDefault();
        }

        public List<ParentTask> GetAllParentTasks()
        {
            ProjectManagementDbContext dbContext = new ProjectManagementDbContext();
            return dbContext.ParentTasks.Distinct<ParentTask>().ToList();
        }

        public string AddTask(Task task)
        {
            ProjectManagementDbContext dbContext = new ProjectManagementDbContext();
            dbContext.Tasks.Add(task);                     

            if(dbContext.SaveChanges() > 0)
            {
                return "Record added Successfully";
            }
            else
            {
                return "Failed. Plese try again later";
            }
        }

        public string EditTask(Task task)
        {
            ProjectManagementDbContext dbContext = new ProjectManagementDbContext();
            Task taskData = dbContext.Tasks.Find(task.TaskID);
            taskData.TaskDesc = task.TaskDesc;
            taskData.StartDate = task.StartDate;
            taskData.EndDate = task.EndDate;
            taskData.Priority = task.Priority;
            taskData.ParentTaskID = task.ParentTaskID;
            taskData.TaskStatus = task.TaskStatus;

            if (dbContext.SaveChanges() > 0)
            {
                return "Record updated Successfully";
            }
            else
            {
                return "Failed. Plese try again later";
            }
        }

        public string  DeleteTask(int id)
        {
            ProjectManagementDbContext dbContext = new ProjectManagementDbContext();
            Task task = dbContext.Tasks.Find(id);
            dbContext.Tasks.Remove(task);

            if (dbContext.SaveChanges() > 0)
            {
                return "Record deleted Successfully";
            }
            else
            {
                return "Failed. Plese try again later";
            }
        }
    }
}
